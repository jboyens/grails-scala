Ant.property(environment: "env")
Ant.mkdir(dir: "${basedir}/src/scala")
